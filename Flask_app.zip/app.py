from flask import Flask, request, render_template, send_file
import os

from style_transfer import neural_style_transfer

app = Flask(__name__)

# Ensure 'uploads' and 'results' directories exist
os.makedirs('uploads', exist_ok=True)
os.makedirs('results', exist_ok=True)

# Pre-loaded style images for each artist
artist_styles = {
    'goya': ('D:static\styles\goya1.jpg', 'static/styles/goya2.jpg'),
    'monet': ('static/styles/Monet_1.jpg', 'static/styles/monet_2.jpg'),
    'picasso': ('static/styles/Picasso_1.jpg', 'static/styles/Picasso_2.jpg')
}

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        # Get uploaded content image
        content_file = request.files['content']
        content_path = os.path.join('uploads', content_file.filename)
        content_file.save(content_path)

        # Get selected artist and corresponding style images
        artist = request.form['artist']
        style_path1, style_path2 = artist_styles.get(artist)

        # Output file path
        output_path = os.path.join('results', 'output.png')

        # Perform neural style transfer using pre-loaded style images
        neural_style_transfer(content_path, style_path1, style_path2)

        # Display the images
        return render_template('result.html', content_image=content_file.filename, output_image='output.png')

    return render_template('index.html')

# Route to display content image
@app.route('/uploads/<filename>')
def uploaded_file(filename):
    return send_file(os.path.join('uploads', filename))

# Route to display output image
@app.route('/results/<filename>')
def result_file(filename):
    return send_file(os.path.join('results', filename))

if __name__ == '__main__':
    app.run(debug=True)
